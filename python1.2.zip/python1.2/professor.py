class Professor: 
    def __init__(self,nome,idade,nota): ##metodo melhor profe
       
        self.nome= nome
        self.idade= idade
        self.nota= nota

    def hello(self):

        print(f"ola thiago {self.nome}")

    def mostrardados(self): #metodo melhor profe 

        print(self.nome)
        print(self.idade)
        print(self.nota)


profe= Professor ("thiago","36","6")
profe.hello 





    







        
        

                
        
    

        
