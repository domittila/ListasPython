class Estudante: #definicao de classe 
    def __init__(self,matricula,nome,idade,nota): ##metodo construtor 
        self.matricula= matricula #atriibuto
        self.nome= nome #atriibuto
        self.idade= idade #atriibuto
        self.nota= nota #atriibuto

    def hello(self):#metodo
        
        print(f"ola {self.nome}")

        aluno= Estudante(1212, "pedro",18,80)

        print(aluno.nome)

        aluno2= Estudante(1313, "Domittila",22,90)

        print(aluno2.nome)