class Pessoa:
    def __init__(self,nome,idade,endereco):
        self.nome= nome
        self.idade= idade
        self.endereco= endereco

    def __str__(self):
           return f'nome:{self.nome},idade:{self.idade}, endereco: {self.endereco}'
    #exemplo de uso:



    
pessoa1=Pessoa ("joao silva", 30,"rua das flores, 123")
print(pessoa1)
    



