from funcoes import *
z = mult(50,50)

print(z)