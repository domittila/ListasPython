class Pessoa: 
    def __init__(self, id= 0, nome= ""):
        self.id= id
        self.id= nome
    def hello(self):
        print(f"ola {self.nome}")

pes1 = Pessoa()

print("BOM DIA")

name= input("Digite seu nome:")

pes1.nome = name 
pes1.hello()


