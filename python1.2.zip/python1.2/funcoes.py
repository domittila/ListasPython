############## arquivo de funcao #################

def soma(n1, n2):
    res= n1 + n2 
    return res

def mult(n1, n2):
    res= n1 * n2 
    return res

def div(n1, n2):
    res= n1 / n2 
    return res

def subtracao(n1, n2):
    res= n1 - n2 
    return res

def pot(n1, n2):
    res= n1 ** n2 
    return res

x = soma(10,20)
y = mult(10,20)
z= pot(3,4)

print(x + y + z)

